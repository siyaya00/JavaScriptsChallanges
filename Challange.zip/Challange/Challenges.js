function sum65(num1, num2){
  num1 = Number(document.getElementById('noOne').value);
  num2 = Number(document.getElementById('noTwo').value);
  var sum = num1 + num2;
  if (sum == 65 || num1 == 65 || num2 == 65)
  document.getElementById('sum65').innerHTML = true;
  else
  document.getElementById('sum65').innerHTML = false;
}

function areaOfTriangle(){
  var side1 = 7;
  var side2 = 8;
  var side3 = 9;
  var p = (side1 + side2 + side3)/2;
  var area = Math.sqrt(p*((p-side1)*(p-side2)*(p-side3)));
  document.getElementById('area').innerHTML = area;
}

function lrgNum(){
var  num1 = Number(document.getElementById('no1').value);
var  num2 = Number(document.getElementById('no2').value);
var  num3 = Number(document.getElementById('no3').value);
  if(num1 > num2 && num1 > num3)
  document.getElementById('lrg').innerHTML = num1;
  else if(num2 > num1 && num2 > num3)
 return document.getElementById('lrg').innerHTML = num2;
  else if (num3 > num1 && num3 > num2)
  document.getElementById('lrg').innerHTML = num3;
}

function time(){
  var number = Number(document.getElementById('bfrConvert').value);
  var hours = (number / 60);
  var mins = (number % 60);
    var time = hours.toFixed(0) + " hour(s), " + mins.toFixed() + " minute(s).";
    document.getElementById('aftrConvert').innerHTML = time;
}

function commonWords(){
  var firstWord = document.getElementById('firstString').value;
  var secondWord = document.getElementById('secondString').value;
  var repLetters = [];

  for(i = 0; i <= firstWord.length; i++){
      if(secondWord.indexOf(firstWord[i]) >= 0)
      repLetters.push(firstWord[i]);
    }
  document.getElementById('repeatLetters').innerHTML = repLetters;
}
